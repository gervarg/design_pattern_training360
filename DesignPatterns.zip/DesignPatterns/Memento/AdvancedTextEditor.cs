﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Memento
{
    // Mi a helyzet, ha nagy objektumokat kell eltárolni?
    // Csak a változások eltárolása: undo/redo (~ Command pattern)
    // Fontos a sorrend, Burkoló osztály
    class AdvancedTextEditorMemento
    {
        // TODO
    }

    class AdvancedTextEditor
    {
        // TODO
    }
}
