﻿namespace FactoryMethod
{
    internal class JsonParser : IParser
    {
    }
}