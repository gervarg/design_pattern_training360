﻿namespace FactoryMethod
{
    internal class GeneralParser : IParser
    {
    }
}