﻿namespace FactoryMethod
{
    internal class XmlParser : IParser
    {
    }
}