﻿namespace FactoryMethod
{
    internal interface IParser
    {
    }
}