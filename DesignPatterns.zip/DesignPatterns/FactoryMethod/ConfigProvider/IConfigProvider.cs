﻿namespace FactoryMethod
{
    internal interface IConfigProvider
    {
        
    }
}