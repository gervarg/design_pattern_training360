﻿namespace FactoryMethod
{
    public enum ConfigProvider
    {
        Json, Xml, Sample
    }
}
