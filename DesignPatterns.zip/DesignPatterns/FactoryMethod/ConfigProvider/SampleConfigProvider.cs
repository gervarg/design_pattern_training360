﻿namespace FactoryMethod
{
    internal class SampleConfigProvider : IConfigProvider
    {
        public override string ToString()
        {
            return "Provide SAMPLE config values.";
        }
    }
}