﻿using System;

namespace SimpleFactory
{    
    class LogFactory
    {
        // Do not use static because of tightly-coupling!
        // More difficult to change and test.
        public static Log CreateLog(string message, Log.LogLevel level, Exception exception = null)
        {
            return new Log
            {
                Level = level,
                Message = message,
                CreatedAt = DateTime.UtcNow,
                CurrentUser = Environment.UserName,
                ServerName = Environment.MachineName,
                StackTrace = exception?.StackTrace
            };
            // Info from services
            // Secure stacktrace
        }
    }
}
