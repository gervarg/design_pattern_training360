﻿namespace Composit
{
    // Részvény
    internal interface IShare
    {
        decimal Price { get; }
    }
}