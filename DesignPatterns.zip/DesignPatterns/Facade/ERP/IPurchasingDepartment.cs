﻿namespace Facade
{
    interface IPurchasingDepartment
    {
        void RequestNewDevice(params Device[] devices);
    }
}