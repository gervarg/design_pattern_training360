﻿namespace Facade
{
    interface IAccountingDepartment
    {
        void IntroduceNewColleague(Colleague colleague);
    }
}