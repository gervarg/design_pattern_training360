﻿namespace Facade
{
    interface IHrDepartment
    {
        void KickOff(Colleague colleague);
    }
}