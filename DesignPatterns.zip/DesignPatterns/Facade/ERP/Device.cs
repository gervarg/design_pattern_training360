﻿namespace Facade
{
    class Device
    {
        public Device(string name)
        {
            Name = name;
        }

        public string Name { get; }
    }
}