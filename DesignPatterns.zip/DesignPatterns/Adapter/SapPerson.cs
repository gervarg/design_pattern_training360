﻿using System;

namespace Adapter
{
    internal class SapPerson
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime BornAt { get; set; }

        public decimal SalaryInEuro { get; set; }
    }
}