﻿namespace AbstractFactory
{
    internal interface IWindow
    {
        void Show();
        void Resize();
    }
}