﻿namespace AbstractFactory
{
    internal interface IButton
    {
        void Show();
        void Click();
    }
}