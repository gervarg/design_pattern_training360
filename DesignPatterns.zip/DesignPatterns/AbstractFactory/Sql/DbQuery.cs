﻿namespace AbstractFactory
{
    internal abstract class DbQuery
    {
        public abstract void Execute();
    }
}